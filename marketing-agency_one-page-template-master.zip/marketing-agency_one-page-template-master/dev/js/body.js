// Include body scripts in the right order
// They will be concatenated using gulp-rigger in body.min.js

//= vendor/jquery.js
//= lib/jquery.navigation.js
//= lib/settings.js

// Google map disabled by default because of empty API key
// It is still available at lib/gmap.js
